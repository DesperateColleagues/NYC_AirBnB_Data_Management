To understand the name attributes of the table you must open and read the file:
-> Metadata_pointsOfInterest.md